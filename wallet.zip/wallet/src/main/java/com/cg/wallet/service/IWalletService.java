package com.cg.wallet.service;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.exception.WalletException;

public interface IWalletService {
	boolean validateAccount(Customer cus) throws WalletException;
	long addAccount(Customer cus)throws WalletException;
	Customer showBalance  (long accu) throws WalletException;
	boolean validateAccount(long accu) throws WalletException;
	double deposit(Long accu, double amt) throws WalletException;
	double withdraw(Long accu, double amt)throws WalletException;
	
	
	
}
