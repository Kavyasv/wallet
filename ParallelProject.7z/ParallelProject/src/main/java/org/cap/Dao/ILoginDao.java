package org.cap.Dao;

import org.cap.model.Customer;

public interface ILoginDao {
public boolean validateLogin(int customerId,String password);
public String getCustomerName(Integer custID);
public Customer findCustomer(int customerId);
}
