package com.cg.wallet.db;

import java.util.HashMap;
import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;



public class WalletDb {
	private static HashMap<Long,Customer>customerMap=new HashMap<Long,Customer>();
	
	
	
	
		static {
			customerMap.put( 1001l, new Customer("kaya","female","7708158541","kaya@gmail.com","21","chennai",1001l,1572));
			customerMap.put( 1002l, new Customer("diya","female","7704148541","diya@gmail.com","23","bangalore",1002l,234));
			customerMap.put(1003l, new Customer("maya","female","7708148541","maya@gmail.com","24","mysore",1003l,3456));
			customerMap.put( 1004l, new Customer("raya","female","7708658541","raya@gmail.com","25","seoul",1004l,3265));
		}

		
	
	public static HashMap<Long,Customer> getCustomerMap() {
		return customerMap;
	}
	
	
	}

