package com.cg.wallet.bean;

public class Customer {
private String name;
private String gender;
private String phone;
private String email;
private String age;
private String address;
private long accId;
private double balance;
















@Override
public String toString() {
	return "Customer [name=" + name + ", gender=" + gender + ", phone=" + phone + ", email=" + email + ", age=" + age
			+ ", address=" + address + ", accId=" + accId + ", balance=" + balance + "]";
}
















/*public int getAccId() {
	return accId;
}

public void setAccId(int accId) {
	acc.accId = accId;
}*/
public Customer(){

}
















public String getName() {
	return name;
}
















public void setName(String name) {
	this.name = name;
}
















public String getGender() {
	return gender;
}
















public void setGender(String gender) {
	this.gender = gender;
}
















public String getPhone() {
	return phone;
}
















public void setPhone(String phone) {
	this.phone = phone;
}

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

public String getAge() {
	return age;
}

public void setAge(String age) {
	this.age = age;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public long getAccId() {
	return accId;
}

public void setAccId(long accId) {
	this.accId = accId;
}

public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
















public Customer(String name, String gender, String phone, String email, String age, String address, long accId,double balance) {
	super();
	this.name = name;
	this.gender = gender;
	this.phone = phone;
	this.email = email;
	this.age = age;
	this.address = address;
	this.accId = accId;
	this.balance=balance;
}

















}
