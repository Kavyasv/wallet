package com.cg.Service;

import java.util.List;

import org.cg.dao.PilotDao;
import org.cg.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotServiceImpl implements PilotService{

	@Autowired
	private PilotDao pilotDao;
	@Override
	public void save(Pilot pilot) {
		
		pilotDao.save(pilot);
	}
	@Override
	public List<Pilot> getAll() {
		
		return pilotDao.getAll();
	}
	@Override
	public void delete(Integer pilotId) {
		pilotDao.delete(pilotId);
		
	}
	@Override
	public Pilot findPilotId(Integer pilotId) {
		
		return pilotDao.findPilotId(pilotId);
	}
	@Override
	public void update(Pilot pilot) {
		
		pilotDao.update(pilot);
	}
	

}
