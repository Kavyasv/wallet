package com.cg.wallet.dao;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.exception.WalletException;

public interface IWalletDao {

	long addAccount(Customer cus)throws WalletException;
	public Customer showBalance(long accu) throws WalletException;
	boolean validateAccount(long accu) throws WalletException;
	public double deposit(Long accu, double amt) throws WalletException;
	double withdraw(Long accu, double amt)throws WalletException;
	
	 
}
