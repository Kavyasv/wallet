package org.cap.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cap.Dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
public class AccountService implements IAccountService{

	@Autowired
	IAccountDao accountDao;
	
	@Override
	public void createAccount(Account account) {
		
		accountDao.createAccount(account);
	}

	@Override
	public List<Account> getAllAccounts(Integer custId) {
		return accountDao.getAllAccounts(custId);
	}
	@Override
	public List<Account> getAccountWithBalance(int custId){
		
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
				Map<Account, Double> deMap = accountDao.getAmountCreDeb(str,custId);
		
			String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
			Map<Account, Double> crMap = accountDao.getAmountCreDeb(str1,custId);
				

			List<Account> accounts=getAllAccounts(custId);
			
			/*ArrayList<Account> accounts=new ArrayList<>();
			for(Account account:accounts1) {
				Account account1=new Account();
				
				account1.setAccountId(account.getAccountId());
				account1.setAccountNo(account.getAccountNo());
				account1.setAccountType(account.getAccountType());
				account1.setOpeningBalance(account.getOpeningBalance());
				account1.setOpeningDate(account.getOpeningDate());
				account1.setStatus(account.getStatus());
				
				accounts.add(account);
			}*/
			
			Iterator<Account> iterator= accounts.iterator();
			while(iterator.hasNext()) {
				Account account=iterator.next();
				double balance=0;
				double crAmt=0,deAmt=0;
				account.setUpdateBalance(0);
				
				if(crMap.get(account) ==null)
					crAmt=0;
				else
					crAmt=crMap.get(account);
				

				if( deMap.get(account) ==null)
					deAmt=0;
				else
					deAmt= deMap.get(account);
				
				
				
				balance=account.getOpeningBalance() +
						crAmt-deAmt;
				
				account.setUpdateBalance(balance);
				
			}
			
			
			return accounts;
			
			
	}

	@Override
	public Account findAccount(long accNo) {
		return accountDao.findAccount(accNo);
	}

	@Override
	public void addTransaction(Transaction transact) {
		accountDao.addTransaction(transact);
		
	}

	@Override
	public List<Account> getAllToAccounts(Integer custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void fundTransfer(Transaction transaction) {
		// TODO Auto-generated method stub
		
	}}

	/*@Override
	public void transfer(Transaction transact) {
		accountDao.transfer(transact);
	}
}*/
