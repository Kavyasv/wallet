package com.cg.wallet.ui;

import java.util.Scanner;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.exception.WalletException;
import com.cg.wallet.service.IWalletService;
import com.cg.wallet.service.WalletService;

public class Client {
	Scanner scan=new Scanner(System.in);
	
	IWalletService walletservice=new WalletService();
	Customer cus=new Customer();

	
	public static void main(String[] args) {
		Client c=new Client();
	
		
				
		c.scan.useDelimiter("\n");
		while(true){
			
			System.out.println("===Banking system===");
				System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.FundTransfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			System.out.println("Enter your option");
			
			String option;
		option=c.scan.nextLine();
		
		switch(option) {
		case "1":
			c.createAccount();
			break;
			
		case "2":
			c.showBalance();
			break;
			
		case "3":
			c.Deposit();
			break;
			
		case "4":
			c.Withdraw();
			break;
			
		case "5":
			c.fundTransfer();
			break;
		case "6":
			c.printTransaction();
						
		case "7":System.exit(0);
			break;
			
			default:
				System.out.println("Invalid option");
				break;
		}

	}
	}


	public void printTransaction() {
		Client c= new Client();
		System.out.println("Your Last Transaction");
		c.showBalance();
		
	}


	public void fundTransfer() {
		System.out.println("Enter the source accountno");
		String acc1=scan.nextLine();
		
		System.out.println("Enter the destination accountNo");
		String acc2=scan.nextLine();
		
		System.out.println("Enter the amount to be transfered");
		String amount=scan.nextLine();
		
		Long account=Long.parseLong(acc1);
		Long account1=Long.parseLong(acc2);
		double amt=Double.parseDouble(amount);
		
		
		try {
			boolean result=walletservice.validateAccount(account);
			boolean result1=walletservice.validateAccount(account1);
			if(result&result1) {
				double bal=(double) walletservice.withdraw(account,amt);
				System.out.println("Source Account"+bal);
				double balance=(double) walletservice.deposit(account1,amt);
				System.out.println("Destination Account"+balance);
			}
		}
		
		
		
		
		catch (WalletException e) {
			
			System.out.println("An error occured"+e.getMessage());
		}
		
		
	}


	public void Withdraw() {
		System.out.println("Enter the account number");
		String account=scan.nextLine();
	Long accu=Long.parseLong(account);
		System.out.println("enter the amount to be withdrawn");
		String amount=scan.nextLine();
		double amt=Long.parseLong(amount);
		
try {
			
			boolean result=walletservice.validateAccount(accu);
			if(result) {
				double bal=(double) walletservice.withdraw(accu,amt);
				System.out.println("Balance:="+bal);
				
			}
		
	}catch(WalletException e) {
		System.out.println("An error occured"+e.getMessage());
	}
		
	}


	public void Deposit() {
		System.out.println("Enter the account number");
		String account=scan.nextLine();
		Long accu=Long.parseLong(account);
		System.out.println("enter the amount to be deposited");
		String amount=scan.nextLine();
		double amt=Long.parseLong(amount);
try {
			
			boolean result=walletservice.validateAccount(accu);
			if(result) {
				double bal=(double) walletservice.deposit(accu,amt);
				System.out.println("Balance:="+bal);
				
			}
		
	}catch(WalletException e) {
		System.out.println("An error occured"+e.getMessage());
	}
	}

	public void showBalance()  {
		System.out.println("Enter the account number to view the balance: ");
		String account=scan.nextLine();
		Long accu=Long.parseLong(account);
		try {
			
			boolean result=walletservice.validateAccount(accu);
			if(result) {
			Customer cus=walletservice.showBalance(accu);
			System.out.println("Your balance for mobile number: "+accu+" is "+cus.getBalance());
			}
		} catch (WalletException e) {
			
			System.err.println("An error occured"  +e.getMessage());}
		}
		
	public void createAccount() {
		Customer request=new Customer();
		System.out.println("Enter the Name");
		request.setName(scan.nextLine());
		System.out.println("Enter the Age");
		request.setAge(scan.nextLine());
		System.out.println("Enter the MobileNumber");
        request.setPhone(scan.nextLine());
        System.out.println("Enter the email Id");
        request.setEmail(scan.nextLine());
    	try {
    		boolean result=walletservice.validateAccount(request);
    		if(result) {
    			long ret=walletservice.addAccount(request);
    			System.out.println("Customer with Id "+ret+ "added successfully");
    		}
    	}
    		catch(WalletException e) {
    			System.out.println();
    			System.out.println("An error occured"+e.getMessage());
    			System.out.println();
    		}
        }

	}
		
	

