package com.cg.wallet.bean;

public class Account {
	
	private int accId;
	private double balance;
	private double minBalance=500;
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Account(int accId, double balance) {
		super();
		this.accId = accId;
		this.balance = balance;
		
	}
	
	public Account() {
		
	}
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", balance=" + balance + ", minBalance=" + minBalance + "]";
	}
	
	
}