package org.cap.Dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("accountDao")
public class AccountDao implements IAccountDao{
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	
	EntityManager em;
	@Override
	public void createAccount(Account account) {
		
		Query query=em.createQuery("select Max(accountNo) from Account");
        List<Long> max= query.getResultList();
		account.setAccountNo(max.get(0)+1);
		em.persist(account);
		}
		
	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(Integer custId) {
		Query query= em.createQuery("from Account acc where acc.customer.customerId=:custId"); 
		query.setParameter("custId", custId);
		List<Account> accounts= query.getResultList();
		return accounts;
	}


	@Transactional(readOnly=true)
	@Override
	public Map<Account, Double> getAmountCreDeb(String strQuery, int custId) {
Query query=em.createQuery(strQuery);
		
		query.setParameter("custId", custId);
		
		List<Transaction> transactions=query.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}

	@Transactional
	public void addTransaction(Transaction transaction) {
				em.persist(transaction);
		
	}

	@Override
	public Account findAccount(long accountNo) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accountNo);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

	@Override
	public List<Account> getAllToAccounts(Integer custId) {
		
		return null;
	}

	@Override
	public void fundTransfer(Transaction transaction) {
		
		
	}


		
	
	
	
	

}
