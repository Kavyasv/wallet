package org.cg.model;

public class PilotTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
