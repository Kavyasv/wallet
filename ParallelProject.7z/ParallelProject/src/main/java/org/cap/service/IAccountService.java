package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountService {

	void createAccount(Account account);

	List<Account> getAllAccounts(Integer custId);

	List<Account> getAccountWithBalance(int custId);

	Account findAccount(long accNo);

	void addTransaction(Transaction transact);

	List<Account> getAllToAccounts(Integer custId);

	void fundTransfer(Transaction transaction);

	
}
