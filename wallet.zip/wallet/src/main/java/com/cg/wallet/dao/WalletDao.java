package com.cg.wallet.dao;

import java.util.HashMap;
import java.util.Optional;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.db.WalletDb;
import com.cg.wallet.exception.WalletException;

public class WalletDao implements IWalletDao {
	
	
	static HashMap<Long,Customer>cusmap=WalletDb.getCustomerMap(); 
	
	public long addAccount(Customer cus) throws WalletException {
		try{
			if(cusmap.size()==0) {
				cus.setAccId(1001);
			}
			else {
				Optional<Long>id=cusmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				long reqid=id.get()+1;
				cus.setAccId(reqid);
			}
			cusmap.put(cus.getAccId(),cus);
		return cus.getAccId();
		}
		catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		}		

	}
	

	@Override
	public Customer showBalance(long accu) throws WalletException  {
		
		Customer cus=cusmap.get(accu);
		
		return cus;
	}

	@Override
	public boolean validateAccount(long accu) throws WalletException {
	
		try {Customer cus=cusmap.get(accu);
		if(cus==null) {
			throw new WalletException("Account doesnt exits");
			
		}
return true;
}
		catch(Exception e) {
			throw new WalletException(e.getMessage());
		}
		
			}

	@Override
	public double deposit(Long accu, double amt) throws WalletException {
		Customer cus=cusmap.get(accu);
		double bal=cus.getBalance();
		cus.setBalance(bal+amt);
		return cus.getBalance();
	}


	@Override
	public double withdraw(Long accu, double amt) throws WalletException {
		Customer cus=cusmap.get(accu);
		double bal=cus.getBalance();
		cus.setBalance(bal-amt);
		return cus.getBalance();
	}


	
	
	
}
