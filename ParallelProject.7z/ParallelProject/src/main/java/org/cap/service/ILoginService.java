package org.cap.service;

import org.cap.model.Customer;

public interface ILoginService {
	
	public boolean validateLogin(int customerId,String password);
	public String getCustomerName(Integer custID);
	public Customer findCustomer(int customerId) ;
	
	
}
