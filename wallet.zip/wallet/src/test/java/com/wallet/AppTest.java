package com.wallet;


import com.cg.wallet.bean.Customer;
import com.cg.wallet.dao.IWalletDao;
import com.cg.wallet.dao.WalletDao;
import com.cg.wallet.exception.WalletException;
import junit.framework.TestCase;



public class AppTest extends TestCase
{ 
	
	IWalletDao dao=new WalletDao();


public void testAddAccount() {
	Customer cus=new Customer();
	cus.setAccId(1005);
	cus.setName("upapa");
	cus.setPhone("9841975354");
	cus.setEmail("sfgfgh@gmail.com");
	cus.setBalance(3465);
	cus.setAddress("chennai");
	cus.setAge("21");
	cus.setGender("male");
	try {
		dao.addAccount( cus);
		Customer emp1=dao.showBalance(1005);
		assertNotNull(cus);
	}
			catch(WalletException e) {
				System.out.println(e.getMessage());
			}
}
public void testshowBalance() {
	try {
		Customer cus=dao.showBalance(1001);
		assertNotNull(cus);
		Customer cust=dao.showBalance(1001);
		assertNotNull(cust);
	}
	catch(WalletException e) {
		System.out.println(e.getMessage());
	}
}

public void testDepositAmount() {
	try {
		double cus=dao.deposit((long) 1001, 1000);
		assertNotNull(cus);
	}
	catch(WalletException e) {
		System.out.println(e.getMessage());
	}
}
   
    
}
