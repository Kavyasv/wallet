package org.cap.Dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountDao {

		void createAccount(Account account);

		List<Account> getAllAccounts(Integer custId);
		public Map<Account, Double> getAmountCreDeb(String strQuery,int custId);
		Account findAccount(long accNo);

		void addTransaction(Transaction transact);
		List<Account> getAllToAccounts(Integer custId);

		void fundTransfer(Transaction transaction);
}
