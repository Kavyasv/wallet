package com.cg.wallet.service;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.dao.IWalletDao;
import com.cg.wallet.dao.WalletDao;
import com.cg.wallet.exception.WalletException;

public class WalletService implements IWalletService {
IWalletDao walletdao=new WalletDao();

	public boolean validateAccount(Customer cus) throws WalletException
	
	{
		
		if(validateName(cus.getName())&& validateMobile(cus.getPhone())
				&&validateEmail(cus.getEmail())) {
			return true;
		}
		return true;
	}
	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty() || name==null) {
			throw new WalletException("Employee name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("Name should start with a Capital letter followed by a minimum of 2 letters");
			}
		}		
		return true;		
	}
	
private boolean validateMobile(String mobile)throws WalletException{
	if(mobile.isEmpty() || mobile==null) {
		throw new WalletException("Mobile Numeber is mandatory");
		
	}
	else {
		if(!mobile.matches("\\d{10}")) {
			throw new WalletException("Mobile Numeber should contain 10 numbers");
			
		}
	}
	return true;
	
}
public boolean validateEmail(String email) throws  WalletException{
	if(!email.matches("[A-za-z0-9_]+@[a-z]+\\.com")) {
		throw new WalletException("Please enter a valid email Id");
	}
	return true;
}
		

	public long addAccount(Customer cus) throws WalletException {
		
		return walletdao.addAccount(cus);
		
	}
	@Override
	public Customer showBalance(long accu) throws WalletException {
		
		return walletdao.showBalance(accu);
	}
	@Override
	public boolean validateAccount(long accu) throws WalletException {
		
		return walletdao.validateAccount(accu);
	}
	@Override
	public double deposit(Long accu, double amt) throws WalletException {
		
		return walletdao.deposit(accu,amt);
	}
	@Override
	public double withdraw(Long accu, double amt) throws WalletException {
		
		return walletdao.withdraw(accu,amt);
	}
	
	
	
	
	

}
